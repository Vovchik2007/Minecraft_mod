package com.nocturne.client.model;

import com.nocturne.NocturneMod;
import com.nocturne.entity.NocturnEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class NocturnModel extends GeoModel<NocturnEntity> {
    @Override public ResourceLocation getModelResource(NocturnEntity animatable) { return new ResourceLocation(NocturneMod.MOD_ID, "geo/nocturn.geo.json"); }
    @Override public ResourceLocation getTextureResource(NocturnEntity animatable) { return new ResourceLocation(NocturneMod.MOD_ID, "textures/entity/nocturn.png"); }
    @Override public ResourceLocation getAnimationResource(NocturnEntity animatable) { return new ResourceLocation(NocturneMod.MOD_ID, "animations/nocturn.animation.json"); }
}
